Skin-builder 5.0


Skin-builder can convert msstyle to Vclskin skin file, click "import" button in toolbar.